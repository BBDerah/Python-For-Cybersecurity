# Week 11: Graph Example
import matplotlib.pyplot as plt
plt.plot([1,2,3], [2,4,1])
plt.title('Login Attempts')
plt.show()