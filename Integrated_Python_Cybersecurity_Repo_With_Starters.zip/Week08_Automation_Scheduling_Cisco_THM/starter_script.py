# Week 8: Scheduled Task
import schedule, time
def job():
    print('Running scan...')
schedule.every(10).seconds.do(job)
while True:
    schedule.run_pending()
    time.sleep(1)