# Week 3: CLI and Conditional
import sys
if len(sys.argv) > 1:
    print(f'Arg: {sys.argv[1]}')
else:
    print('No args provided')