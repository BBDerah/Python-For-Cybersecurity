# Integrated Python for Cybersecurity (Cisco + TryHackMe)

This repository tracks a 12-week hands-on Python learning journey for cybersecurity, integrating:

- 🧠 Cisco Networking Academy Python Essentials 1 & 2
- 🧪 TryHackMe hands-on cybersecurity rooms
- 🛠️ Custom weekly scripting challenges and project folders

## 📆 Weekly Plan Overview

Each folder includes:
- Scripts and tools developed during the week
- Notes from Cisco chapters and TryHackMe rooms
- A mini-task script for practical testing

## 🧠 Learning Focus

- Python foundations (CLI, files, functions, error handling)
- Cybersecurity scripting (log analysis, scanning, APIs, hashing)
- Red team automation & blue team detection
- Graphing security data and final project

## 📌 Final Project (Week 12)

Build a red or blue team toolkit, document it, and host the code on GitHub.

---

Organize your code per week. Push weekly commits to track your growth!
