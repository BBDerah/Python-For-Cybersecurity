# Week 9: Log Monitor
with open('/var/log/auth.log') as log:
    for line in log:
        if 'Failed password' in line:
            print(line.strip())