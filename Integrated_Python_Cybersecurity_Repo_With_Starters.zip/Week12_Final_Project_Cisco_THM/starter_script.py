# Week 12: Start Your Final Project Here
print('Start building your red or blue team toolkit!')