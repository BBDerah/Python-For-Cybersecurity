# Week 2: Function and File Example
def greet(name):
    return f'Hello {name}'

print(greet('Analyst'))