# Week 4: Regex Example
import re
log = 'Failed login from 192.168.1.100'
ip = re.findall(r'\d+\.\d+\.\d+\.\d+', log)
print(ip)