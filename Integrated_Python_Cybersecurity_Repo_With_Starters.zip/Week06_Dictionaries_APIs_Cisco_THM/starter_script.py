# Week 6: API and JSON
import requests
response = requests.get('https://api.github.com')
print(response.json())