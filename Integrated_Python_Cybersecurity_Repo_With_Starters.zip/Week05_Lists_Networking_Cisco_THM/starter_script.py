# Week 5: Port Scanner
import socket
for port in range(20, 25):
    with socket.socket() as s:
        result = s.connect_ex(('127.0.0.1', port))
        print(f'Port {port}:', 'Open' if result == 0 else 'Closed')