# Week 1: Basic I/O and Variables
print('Hello, Cybersecurity World!')