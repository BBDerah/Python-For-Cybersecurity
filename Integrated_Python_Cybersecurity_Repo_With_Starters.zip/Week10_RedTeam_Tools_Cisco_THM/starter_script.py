# Week 10: Directory Bruteforce
import requests
paths = ['admin', 'login', 'dashboard']
for p in paths:
    res = requests.get(f'http://example.com/{p}')
    print(p, res.status_code)