# Week 7: File Hashing
import hashlib
with open('test.txt', 'rb') as f:
    print(hashlib.sha256(f.read()).hexdigest())